<?php

namespace zHumpyDev;

use pocketmine\inventory\transaction\action\SlotChangeAction;
use pocketmine\item\Item;
use pocketmine\Player;
use pocketmine\utils\TextFormat as TF;

use muqsit\invmenu\InvMenuHandler;
use muqsit\invmenu\InvMenu;

class LobbyItems {

    private $plugin;
    private $prefix = "";

    public function __Construct(Main $plugin){
        $this->plugin = $plugin;
        
        if (!InvMenuHandler::isRegistered()) {
            InvMenuHandler::register($plugin);
        }

    }

    public function LobbyItems(Player $player)
    {
        $menu = InvMenu::create(InvMenu::TYPE_CHEST);
        
        $menu->readonly();
        $menu->setName(TF::GOLD . "» Navigator «");

        $knockffa = Item::get(280, 0, 1);
        $knockffa->setCustomName(TF::RESET . TF::BLUE . "KnockFFA");
	 
	 $ovso = Item::get(267, 0, 1);
        $ovso->setCustomName(TF::RESET . TF::BLUE . "1vs1");
	 
	 $skywars = Item::get(2, 0, 1);
        $skywars->setCustomName(TF::RESET . TF::BLUE . "SkyWars");
	 
	 $pushwars = Item::get(355, 14, 1);
        $pushwars->setCustomName(TF::RESET . TF::BLUE . "PushWars");
	 
	$air = Item::get(160, 0, 1);
       $air->setCustomName("");
	
	$air1 = Item::get(160, 15, 1);
       $air1->setCustomName("");
        $inv = $menu->getInventory();
        
	 $inv->setItem(0, $air);
	 $inv->setItem(1, $air1);
	 $inv->setItem(2, $air);	 $inv->setItem(3, $air1);	 $inv->setItem(4, $air);
	 $inv->setItem(5, $air1);
	 $inv->setItem(6, $air);	 $inv->setItem(7, $air1);	 $inv->setItem(8, $air);
	 	 $inv->setItem(9, $air1);
        $inv->setItem(10, $knockffa);
        $inv->setItem(11, $air1);
        $inv->setItem(12, $ovso);
        $inv->setItem(13, $air1);
        $inv->setItem(14, $skywars);
        $inv->setItem(15, $air1);
        $inv->setItem(16, $pushwars);
        $inv->setItem(17, $air1);
        
	 $inv->setItem(18, $air);
	 $inv->setItem(19, $air1);
	 $inv->setItem(20, $air);	 $inv->setItem(21, $air1);	 $inv->setItem(22, $air);
	 $inv->setItem(23, $air1);
	 $inv->setItem(24, $air);	 $inv->setItem(25, $air1);	 $inv->setItem(26, $air);
	 
        $menu->setListener([$this, "onTransaction"]);
        $menu->setListener(function(player $player, item $itemClickedOn, Item $itemClickedwith): bool{
            $name = $player->getName();
            if($itemClickedOn->getCustomName() == TF::RESET . TF::BLUE . "KnockFFA"){
            
            	$player->transfer("toxmaticmc.tk", "19132");
            	
            }
            
            if($itemClickedOn->getCustomName() == TF::RESET . TF::BLUE . "1vs1"){
            
            	$player->transfer("toxmaticmc.tk", "19132");
            	
            } 
            
            if($itemClickedOn->getCustomName() == TF::RESET . TF::BLUE . "SkyWars"){
            
            	$player->transfer("toxmaticmc.tk", "19132");
            	
            }
            
            if($itemClickedOn->getCustomName() == TF::RESET . TF::BLUE . "PushWars"){
            
            	$player->transfer("toxmaticmc.tk", "19132");
            	
            }
            return true;
        });

        $menu->send($player);
    }
    public function onTransaction(Player $player, Item $itemTakenOut, Item $itemPutIn, SlotChangeAction $inventoryAction) : bool{

        $player->removeWindow($inventoryAction->getInventory());

        return true;
    }
}